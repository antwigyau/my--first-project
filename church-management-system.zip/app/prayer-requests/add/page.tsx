'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import Link from 'next/link'

export default function AddPrayerRequestPage() {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [user, setUser] = useState<any>(null)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const checkAuth = async () => {
      const {
        data: { user: authUser },
      } = await supabase.auth.getUser()

      if (!authUser) {
        router.push('/auth/login')
        return
      }

      const { data: userProfile } = await supabase.from('users').select('*').eq('id', authUser.id).single()

      setUser(userProfile)
    }

    checkAuth()
  }, [supabase, router])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      const {
        data: { user: authUser },
      } = await supabase.auth.getUser()

      if (!authUser) {
        setError('You must be logged in to submit a prayer request.')
        return
      }

      // Find member associated with this user
      const { data: memberData } = await supabase.from('members').select('id').eq('user_id', authUser.id).single()

      const { error: insertError } = await supabase.from('prayer_requests').insert({
        ...formData,
        member_id: memberData?.id || null,
        is_resolved: false,
      })

      if (insertError) {
        setError(insertError.message)
      } else {
        router.push('/prayer-requests')
      }
    } catch (err) {
      setError('Failed to submit prayer request. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link href="/prayer-requests">
            <h1 className="text-2xl font-bold text-slate-900 hover:text-slate-700">Church Management</h1>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card className="p-8">
          <h2 className="text-3xl font-bold text-slate-900 mb-6">Share a Prayer Request</h2>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-slate-900 mb-2">Prayer Request Title</label>
              <Input
                type="text"
                name="title"
                placeholder="What would you like prayer for?"
                value={formData.title}
                onChange={handleChange}
                required
                disabled={loading}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-900 mb-2">Details (Optional)</label>
              <textarea
                name="description"
                placeholder="Share more details about your prayer request..."
                value={formData.description}
                onChange={handleChange}
                disabled={loading}
                rows={6}
                className="w-full px-3 py-2 border border-slate-300 rounded-md text-sm"
              />
            </div>

            <div className="bg-blue-50 border border-blue-200 p-4 rounded-md">
              <p className="text-sm text-blue-800">
                Your prayer request will be shared with the church community. Your identity will be visible to church leadership.
              </p>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md">
                {error}
              </div>
            )}

            <div className="flex gap-4">
              <Button type="submit" className="bg-amber-600 hover:bg-amber-700 text-white" disabled={loading}>
                {loading ? 'Submitting...' : 'Submit Prayer Request'}
              </Button>
              <Link href="/prayer-requests">
                <Button variant="outline" disabled={loading}>
                  Cancel
                </Button>
              </Link>
            </div>
          </form>
        </Card>
      </main>
    </div>
  )
}
