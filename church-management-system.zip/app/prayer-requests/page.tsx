'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import Link from 'next/link'

interface PrayerRequest {
  id: string
  title: string
  description: string | null
  is_resolved: boolean
  member_id: string | null
  created_at: string
  updated_at: string
}

interface Member {
  id: string
  first_name: string
  last_name: string
}

export default function PrayerRequestsPage() {
  const [requests, setRequests] = useState<PrayerRequest[]>([])
  const [members, setMembers] = useState<Record<string, Member>>({})
  const [loading, setLoading] = useState(true)
  const [filterResolved, setFilterResolved] = useState(false)
  const [user, setUser] = useState<any>(null)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const fetchData = async () => {
      try {
        const {
          data: { user: authUser },
        } = await supabase.auth.getUser()

        if (!authUser) {
          router.push('/auth/login')
          return
        }

        const { data: userProfile } = await supabase.from('users').select('*').eq('id', authUser.id).single()

        setUser(userProfile)

        // Fetch prayer requests
        const { data: requestsData } = await supabase
          .from('prayer_requests')
          .select('*')
          .order('created_at', { ascending: false })

        if (requestsData) {
          setRequests(requestsData)

          // Fetch member names
          const memberIds = [...new Set(requestsData.map((r) => r.member_id).filter(Boolean))]
          if (memberIds.length > 0) {
            const { data: membersData } = await supabase.from('members').select('id, first_name, last_name').in('id', memberIds)

            const memberMap: Record<string, Member> = {}
            membersData?.forEach((m) => {
              memberMap[m.id] = m
            })
            setMembers(memberMap)
          }
        }
      } catch (error) {
        console.error('Error fetching prayer requests:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [supabase, router])

  const filteredRequests = filterResolved ? requests.filter((r) => r.is_resolved) : requests.filter((r) => !r.is_resolved)

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <Link href="/dashboard">
                <h1 className="text-2xl font-bold text-slate-900 hover:text-slate-700">Church Management</h1>
              </Link>
            </div>
            <Button variant="outline" onClick={() => router.push('/dashboard')}>
              Back
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-3xl font-bold text-slate-900">Prayer Requests</h2>
              <p className="text-slate-600 mt-1">Share and support one another in prayer</p>
            </div>
            <Link href="/prayer-requests/add">
              <Button className="bg-amber-600 hover:bg-amber-700 text-white">Add Request</Button>
            </Link>
          </div>

          {/* Filter Tabs */}
          <div className="flex gap-4">
            <button
              onClick={() => setFilterResolved(false)}
              className={`px-4 py-2 rounded-md font-medium transition-colors ${
                !filterResolved ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
              }`}
            >
              Active ({requests.filter((r) => !r.is_resolved).length})
            </button>
            <button
              onClick={() => setFilterResolved(true)}
              className={`px-4 py-2 rounded-md font-medium transition-colors ${
                filterResolved ? 'bg-green-600 text-white' : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
              }`}
            >
              Resolved ({requests.filter((r) => r.is_resolved).length})
            </button>
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <p className="text-slate-600">Loading prayer requests...</p>
          </div>
        ) : filteredRequests.length === 0 ? (
          <Card className="p-12 text-center">
            <p className="text-slate-600 mb-4">{filterResolved ? 'No resolved requests' : 'No active prayer requests'}</p>
            {!filterResolved && (
              <Link href="/prayer-requests/add">
                <Button className="bg-amber-600 hover:bg-amber-700 text-white">Add Prayer Request</Button>
              </Link>
            )}
          </Card>
        ) : (
          <div className="space-y-4">
            {filteredRequests.map((request) => (
              <Card key={request.id} className={`p-6 ${request.is_resolved ? 'bg-slate-50' : ''}`}>
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-slate-900">{request.title}</h3>
                    <p className="text-sm text-slate-500 mt-1">
                      By{' '}
                      {request.member_id && members[request.member_id]
                        ? `${members[request.member_id].first_name} ${members[request.member_id].last_name}`
                        : 'Anonymous'}{' '}
                      • {new Date(request.created_at).toLocaleDateString()}
                    </p>
                  </div>
                  {request.is_resolved && (
                    <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-xs font-medium">
                      Resolved
                    </span>
                  )}
                </div>
                {request.description && <p className="text-slate-700 mb-4">{request.description}</p>}
                {user?.role === 'admin' && (
                  <Button variant="outline" size="sm">
                    {request.is_resolved ? 'Mark Unresolved' : 'Mark Resolved'}
                  </Button>
                )}
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
