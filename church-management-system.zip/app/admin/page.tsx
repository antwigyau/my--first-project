'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import Link from 'next/link'

interface AdminUser {
  id: string
  email: string
  role: string
  first_name: string | null
  last_name: string | null
  created_at: string
}

export default function AdminPage() {
  const [users, setUsers] = useState<AdminUser[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [searchTerm, setSearchTerm] = useState('')
  const [user, setUser] = useState<any>(null)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const fetchData = async () => {
      try {
        const {
          data: { user: authUser },
        } = await supabase.auth.getUser()

        if (!authUser) {
          router.push('/auth/login')
          return
        }

        const { data: userProfile } = await supabase.from('users').select('*').eq('id', authUser.id).single()

        if (userProfile?.role !== 'admin') {
          router.push('/dashboard')
          return
        }

        setUser(userProfile)

        // Fetch all users
        const { data: usersData, error: usersError } = await supabase.from('users').select('*').order('created_at', { ascending: false })

        if (usersError) {
          setError(usersError.message)
        } else {
          setUsers(usersData || [])
        }
      } catch (err) {
        console.error('Error fetching admin data:', err)
        setError('Failed to load admin data')
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [supabase, router])

  const filteredUsers = users.filter(
    (u) =>
      u.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (u.first_name && u.first_name.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (u.last_name && u.last_name.toLowerCase().includes(searchTerm.toLowerCase()))
  )

  const handleRoleChange = async (userId: string, newRole: string) => {
    try {
      const { error: updateError } = await supabase.from('users').update({ role: newRole }).eq('id', userId)

      if (updateError) {
        setError(updateError.message)
      } else {
        setUsers((prevUsers) => prevUsers.map((u) => (u.id === userId ? { ...u, role: newRole } : u)))
      }
    } catch (err) {
      setError('Failed to update user role')
    }
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <Link href="/dashboard">
                <h1 className="text-2xl font-bold text-slate-900 hover:text-slate-700">Church Management</h1>
              </Link>
            </div>
            <Button variant="outline" onClick={() => router.push('/dashboard')}>
              Back
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-slate-900 mb-2">Admin Settings</h2>
          <p className="text-slate-600">Manage users and system settings</p>
        </div>

        {/* Users Management */}
        <Card className="p-6 mb-8">
          <h3 className="text-2xl font-bold text-slate-900 mb-6">User Management</h3>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md mb-6">
              {error}
            </div>
          )}

          <Input
            type="text"
            placeholder="Search users..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="mb-6"
          />

          {loading ? (
            <p className="text-slate-600">Loading users...</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-100 border-b border-slate-200">
                  <tr>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-slate-900">Name</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-slate-900">Email</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-slate-900">Role</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-slate-900">Joined</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-slate-900">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {filteredUsers.map((u) => (
                    <tr key={u.id} className="hover:bg-slate-50">
                      <td className="px-6 py-4 text-sm text-slate-900">
                        {u.first_name} {u.last_name}
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600">{u.email}</td>
                      <td className="px-6 py-4 text-sm">
                        <select
                          value={u.role}
                          onChange={(e) => handleRoleChange(u.id, e.target.value)}
                          disabled={u.id === user?.id}
                          className="px-3 py-1 border border-slate-300 rounded-md text-sm"
                        >
                          <option value="member">Member</option>
                          <option value="secretary">Secretary</option>
                          <option value="treasurer">Treasurer</option>
                          <option value="deacon">Deacon</option>
                          <option value="admin">Admin</option>
                        </select>
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600">
                        {new Date(u.created_at).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 text-sm">
                        {u.id === user?.id ? (
                          <span className="text-slate-500 text-xs">(Current)</span>
                        ) : (
                          <Button variant="outline" size="sm">
                            View
                          </Button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>

        {/* Settings */}
        <Card className="p-6">
          <h3 className="text-2xl font-bold text-slate-900 mb-6">System Settings</h3>

          <div className="space-y-6">
            <div className="border-b border-slate-200 pb-6">
              <h4 className="text-lg font-semibold text-slate-900 mb-2">Church Information</h4>
              <p className="text-slate-600 text-sm mb-4">Configure basic church details</p>
              <Button className="bg-blue-600 hover:bg-blue-700 text-white">Edit Church Settings</Button>
            </div>

            <div className="border-b border-slate-200 pb-6">
              <h4 className="text-lg font-semibold text-slate-900 mb-2">Email Configuration</h4>
              <p className="text-slate-600 text-sm mb-4">Set up email notifications</p>
              <Button className="bg-blue-600 hover:bg-blue-700 text-white">Configure Email</Button>
            </div>

            <div>
              <h4 className="text-lg font-semibold text-slate-900 mb-2">Backups & Exports</h4>
              <p className="text-slate-600 text-sm mb-4">Backup your church data</p>
              <Button className="bg-green-600 hover:bg-green-700 text-white">Export Data</Button>
            </div>
          </div>
        </Card>
      </main>
    </div>
  )
}
