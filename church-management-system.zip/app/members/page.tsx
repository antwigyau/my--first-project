'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import Link from 'next/link'

interface Member {
  id: string
  first_name: string
  last_name: string
  email: string
  phone_number: string
  zone: string
  department: string | null
  joined_date: string
  is_active: boolean
}

export default function MembersPage() {
  const [members, setMembers] = useState<Member[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [user, setUser] = useState<any>(null)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Check user role
        const {
          data: { user: authUser },
        } = await supabase.auth.getUser()

        if (!authUser) {
          router.push('/auth/login')
          return
        }

        const { data: userProfile } = await supabase.from('users').select('*').eq('id', authUser.id).single()

        if (userProfile?.role !== 'admin' && userProfile?.role !== 'secretary') {
          router.push('/dashboard')
          return
        }

        setUser(userProfile)

        // Fetch members
        const { data: membersData, error } = await supabase
          .from('members')
          .select('*')
          .order('joined_date', { ascending: false })

        if (!error && membersData) {
          setMembers(membersData as Member[])
        }
      } catch (error) {
        console.error('Error fetching members:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [supabase, router])

  const filteredMembers = members.filter(
    (member) =>
      member.first_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      member.last_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      member.email.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <Link href="/dashboard">
                <h1 className="text-2xl font-bold text-slate-900 hover:text-slate-700">Church Management</h1>
              </Link>
            </div>
            <Button variant="outline" onClick={() => router.push('/dashboard')}>
              Back
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-3xl font-bold text-slate-900">Members Directory</h2>
              <p className="text-slate-600 mt-1">Total: {filteredMembers.length} members</p>
            </div>
            <Link href="/members/add">
              <Button className="bg-blue-600 hover:bg-blue-700 text-white">Add Member</Button>
            </Link>
          </div>

          <Input
            type="text"
            placeholder="Search members by name or email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="mb-6"
          />
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <p className="text-slate-600">Loading members...</p>
          </div>
        ) : filteredMembers.length === 0 ? (
          <Card className="p-12 text-center">
            <p className="text-slate-600 mb-4">No members found</p>
            <Link href="/members/add">
              <Button className="bg-blue-600 hover:bg-blue-700 text-white">Add First Member</Button>
            </Link>
          </Card>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-100 border-b border-slate-200">
                <tr>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-slate-900">Name</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-slate-900">Email</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-slate-900">Phone</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-slate-900">Zone</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-slate-900">Department</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-slate-900">Joined</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-slate-900">Status</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-slate-900">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {filteredMembers.map((member) => (
                  <tr key={member.id} className="hover:bg-slate-50">
                    <td className="px-6 py-4 text-sm text-slate-900">
                      {member.first_name} {member.last_name}
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-600">{member.email}</td>
                    <td className="px-6 py-4 text-sm text-slate-600">{member.phone_number || 'N/A'}</td>
                    <td className="px-6 py-4 text-sm text-slate-600 capitalize">{member.zone}</td>
                    <td className="px-6 py-4 text-sm text-slate-600 capitalize">{member.department || 'N/A'}</td>
                    <td className="px-6 py-4 text-sm text-slate-600">
                      {new Date(member.joined_date).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 text-sm">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-medium ${
                          member.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                        }`}
                      >
                        {member.is_active ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm">
                      <Link href={`/members/${member.id}`}>
                        <Button variant="outline" size="sm">
                          View
                        </Button>
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </main>
    </div>
  )
}
