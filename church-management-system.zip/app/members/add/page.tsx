'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import Link from 'next/link'

const ZONES = ['accra', 'tema', 'kasoa', 'kumasi', 'cape_coast']
const DEPARTMENTS = ['choir', 'ushering', 'youth', 'women', 'men', 'media', 'welfare', 'finance', 'pastoral_care', 'outreach']

export default function AddMemberPage() {
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    email: '',
    phone_number: '',
    date_of_birth: '',
    zone: 'accra',
    department: '',
    next_of_kin_name: '',
    next_of_kin_phone: '',
    next_of_kin_relationship: '',
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [user, setUser] = useState<any>(null)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const checkAuth = async () => {
      const {
        data: { user: authUser },
      } = await supabase.auth.getUser()

      if (!authUser) {
        router.push('/auth/login')
        return
      }

      const { data: userProfile } = await supabase.from('users').select('*').eq('id', authUser.id).single()

      if (userProfile?.role !== 'admin' && userProfile?.role !== 'secretary') {
        router.push('/dashboard')
        return
      }

      setUser(userProfile)
    }

    checkAuth()
  }, [supabase, router])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      const { error: insertError } = await supabase.from('members').insert({
        ...formData,
        is_active: true,
        joined_date: new Date().toISOString().split('T')[0],
      })

      if (insertError) {
        setError(insertError.message)
      } else {
        router.push('/members')
      }
    } catch (err) {
      setError('Failed to add member. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link href="/members">
            <h1 className="text-2xl font-bold text-slate-900 hover:text-slate-700">Church Management</h1>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card className="p-8">
          <h2 className="text-3xl font-bold text-slate-900 mb-6">Add New Member</h2>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Personal Information */}
            <div>
              <h3 className="text-lg font-semibold text-slate-900 mb-4">Personal Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input
                  type="text"
                  name="first_name"
                  placeholder="First Name"
                  value={formData.first_name}
                  onChange={handleChange}
                  required
                  disabled={loading}
                />
                <Input
                  type="text"
                  name="last_name"
                  placeholder="Last Name"
                  value={formData.last_name}
                  onChange={handleChange}
                  required
                  disabled={loading}
                />
                <Input
                  type="email"
                  name="email"
                  placeholder="Email"
                  value={formData.email}
                  onChange={handleChange}
                  disabled={loading}
                />
                <Input
                  type="tel"
                  name="phone_number"
                  placeholder="Phone Number"
                  value={formData.phone_number}
                  onChange={handleChange}
                  disabled={loading}
                />
                <Input
                  type="date"
                  name="date_of_birth"
                  value={formData.date_of_birth}
                  onChange={handleChange}
                  disabled={loading}
                />
              </div>
            </div>

            {/* Church Information */}
            <div>
              <h3 className="text-lg font-semibold text-slate-900 mb-4">Church Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <select
                  name="zone"
                  value={formData.zone}
                  onChange={handleChange}
                  disabled={loading}
                  className="px-3 py-2 border border-slate-300 rounded-md text-sm"
                >
                  {ZONES.map((zone) => (
                    <option key={zone} value={zone}>
                      {zone.charAt(0).toUpperCase() + zone.slice(1)}
                    </option>
                  ))}
                </select>

                <select
                  name="department"
                  value={formData.department}
                  onChange={handleChange}
                  disabled={loading}
                  className="px-3 py-2 border border-slate-300 rounded-md text-sm"
                >
                  <option value="">Select Department (Optional)</option>
                  {DEPARTMENTS.map((dept) => (
                    <option key={dept} value={dept}>
                      {dept.charAt(0).toUpperCase() + dept.slice(1).replace(/_/g, ' ')}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Next of Kin */}
            <div>
              <h3 className="text-lg font-semibold text-slate-900 mb-4">Next of Kin (Emergency Contact)</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input
                  type="text"
                  name="next_of_kin_name"
                  placeholder="Next of Kin Name"
                  value={formData.next_of_kin_name}
                  onChange={handleChange}
                  disabled={loading}
                />
                <Input
                  type="tel"
                  name="next_of_kin_phone"
                  placeholder="Next of Kin Phone"
                  value={formData.next_of_kin_phone}
                  onChange={handleChange}
                  disabled={loading}
                />
                <Input
                  type="text"
                  name="next_of_kin_relationship"
                  placeholder="Relationship"
                  value={formData.next_of_kin_relationship}
                  onChange={handleChange}
                  disabled={loading}
                />
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md">
                {error}
              </div>
            )}

            <div className="flex gap-4">
              <Button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white" disabled={loading}>
                {loading ? 'Adding...' : 'Add Member'}
              </Button>
              <Link href="/members">
                <Button variant="outline" disabled={loading}>
                  Cancel
                </Button>
              </Link>
            </div>
          </form>
        </Card>
      </main>
    </div>
  )
}
