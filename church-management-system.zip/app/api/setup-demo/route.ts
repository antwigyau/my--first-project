'use server'

import { createClient } from '@/lib/supabase/server'

export async function POST() {
  try {
    const supabase = await createClient()

    // First, try to sign up the user
    const { data, error } = await supabase.auth.signUp({
      email: 'admin@church.local',
      password: 'Admin123456!',
      options: {
        data: {
          first_name: 'Admin',
          last_name: 'User',
        },
      },
    })

    if (error) {
      return Response.json({ success: false, error: error.message }, { status: 400 })
    }

    if (!data.user?.id) {
      return Response.json(
        { success: false, error: 'User creation failed' },
        { status: 400 }
      )
    }

    // Create user profile in public.users table
    const { error: profileError } = await supabase
      .from('users')
      .insert({
        id: data.user.id,
        email: 'admin@church.local',
        role: 'admin',
        first_name: 'Admin',
        last_name: 'User',
      })

    if (profileError && !profileError.message.includes('duplicate')) {
      return Response.json(
        { success: false, error: profileError.message },
        { status: 400 }
      )
    }

    return Response.json({
      success: true,
      message: 'Admin account created successfully',
      email: 'admin@church.local',
      password: 'Admin123456!',
    })
  } catch (err) {
    console.error('[v0] Setup error:', err)
    return Response.json(
      { success: false, error: 'Setup failed' },
      { status: 500 }
    )
  }
}
