import { streamText, convertToModelMessages } from 'ai'
import { createClient } from '@/lib/supabase/server'

export async function POST(req: Request) {
  try {
    const { messages } = await req.json()

    // Get current user for context
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return new Response('Unauthorized', { status: 401 })
    }

    // Fetch user profile for context
    const { data: userProfile } = await supabase.from('users').select('*').eq('id', user.id).single()

    // Fetch church statistics for assistant context
    const [members, financial, events, prayers] = await Promise.all([
      supabase.from('members').select('id', { count: 'exact' }),
      supabase.from('financial_sessions').select('amount'),
      supabase.from('events').select('id', { count: 'exact' }).gte('event_date', new Date().toISOString().split('T')[0]),
      supabase.from('prayer_requests').select('id', { count: 'exact' }).eq('is_resolved', false),
    ])

    const totalGiving = financial.data?.reduce((sum, item) => sum + (parseFloat(item.amount) || 0), 0) || 0

    const systemPrompt = `You are a helpful Church Management Assistant for a Christian church. You help members and church staff with various church-related tasks and questions.

Current Church Statistics:
- Total Members: ${members.count || 0}
- Total Giving (All Time): GHS ${totalGiving.toFixed(2)}
- Upcoming Events: ${events.count || 0}
- Active Prayer Requests: ${prayers.count || 0}

User Information:
- Name: ${userProfile?.first_name} ${userProfile?.last_name}
- Role: ${userProfile?.role || 'Member'}
- Email: ${userProfile?.email}

You can help with:
1. Answering questions about church events, services, and schedules
2. Providing information about church members (directory access)
3. Helping with financial information and giving
4. Discussing prayer requests and spiritual matters
5. Providing guidance on church policies and procedures
6. Suggesting ways to get involved in church activities
7. Answering questions about different church departments and ministries

Be friendly, helpful, and pastoral in your responses. Always prioritize the spiritual wellbeing and community of the church. If you don't have specific information, offer to help them find the right person or resource.`

    const result = streamText({
      model: 'anthropic/claude-3-5-sonnet',
      system: systemPrompt,
      messages: await convertToModelMessages(messages),
    })

    return result.toTextStreamResponse()
  } catch (error) {
    console.error('Assistant API error:', error)
    return new Response('Internal Server Error', { status: 500 })
  }
}
