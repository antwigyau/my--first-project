'use server'

import { createClient } from '@/lib/supabase/server'

export async function POST() {
  try {
    const supabase = await createClient()

    // Create a test admin user in Supabase Auth
    const testEmail = 'admin@church.local'
    const testPassword = 'Admin123456!'

    const { data: authData, error: authError } = await supabase.auth.admin.createUser({
      email: testEmail,
      password: testPassword,
      email_confirm: true, // Auto-confirm email
      user_metadata: {
        first_name: 'Admin',
        last_name: 'User',
      },
    })

    if (authError) {
      // User might already exist, try signing in instead
      console.log('[v0] Auth error:', authError.message)
      return Response.json(
        {
          success: false,
          message: authError.message,
          credentials: {
            email: testEmail,
            password: testPassword,
          },
        },
        { status: 400 },
      )
    }

    if (!authData.user) {
      return Response.json({ success: false, message: 'Failed to create user' }, { status: 400 })
    }

    // Create user profile in public.users table
    const { error: profileError } = await supabase.from('users').insert({
      id: authData.user.id,
      email: testEmail,
      role: 'admin',
      first_name: 'Admin',
      last_name: 'User',
      phone_number: '+233501234567',
      zone: 'accra',
      department: 'finance',
    })

    if (profileError && !profileError.message.includes('duplicate')) {
      console.log('[v0] Profile error:', profileError)
      return Response.json(
        {
          success: false,
          message: profileError.message,
        },
        { status: 400 },
      )
    }

    return Response.json({
      success: true,
      message: 'Seed data created successfully!',
      credentials: {
        email: testEmail,
        password: testPassword,
      },
    })
  } catch (error) {
    console.error('[v0] Seed error:', error)
    return Response.json(
      {
        success: false,
        message: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 },
    )
  }
}
