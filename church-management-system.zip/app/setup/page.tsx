'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'

export default function SetupPage() {
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const handleSeed = async () => {
    setLoading(true)
    setMessage(null)
    setError(null)

    try {
      const response = await fetch('/api/setup-demo', {
        method: 'POST',
      })

      const data = await response.json()

      if (data.success) {
        setMessage(`✓ Admin user created successfully!\n\nEmail: ${data.email}\nPassword: ${data.password}\n\nYou can now log in!`)
      } else {
        setError(data.error || 'Setup failed')
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-white shadow-xl border-0">
        <div className="p-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Church Management Setup</h1>
          <p className="text-slate-600 mb-6">Initialize the demo admin account to get started</p>

          <Button
            onClick={handleSeed}
            disabled={loading}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white mb-4"
          >
            {loading ? 'Setting up...' : 'Create Demo Admin Account'}
          </Button>

          {message && (
            <div className="bg-green-50 border border-green-200 text-green-900 p-4 rounded-md whitespace-pre-line text-sm font-mono">
              {message}
            </div>
          )}

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-900 p-4 rounded-md text-sm">
              Error: {error}
            </div>
          )}

          <div className="mt-6 text-center">
            <p className="text-slate-600 mb-2">Once setup is complete, go to:</p>
            <a href="/auth/login" className="text-blue-600 hover:text-blue-700 font-medium">
              Login Page
            </a>
          </div>
        </div>
      </Card>
    </div>
  )
}
