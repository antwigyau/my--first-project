'use client'

import { useEffect, useState, useRef } from 'react'
import { useRouter } from 'next/navigation'
import { useChat } from '@ai-sdk/react'
import { createClient } from '@/lib/supabase/client'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import Link from 'next/link'

export default function AssistantPage() {
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()
  const supabase = createClient()
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const { messages, input, setInput, handleSubmit } = useChat({
    api: '/api/assistant',
  })

  useEffect(() => {
    const checkAuth = async () => {
      const {
        data: { user: authUser },
      } = await supabase.auth.getUser()

      if (!authUser) {
        router.push('/auth/login')
        return
      }

      const { data: userProfile } = await supabase.from('users').select('*').eq('id', authUser.id).single()

      if (!userProfile) {
        router.push('/dashboard')
        return
      }

      setUser(userProfile)
      setLoading(false)
    }

    checkAuth()
  }, [supabase, router])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <p className="text-slate-600">Loading...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <Link href="/dashboard">
                <h1 className="text-2xl font-bold text-slate-900 hover:text-slate-700">Church Management</h1>
              </Link>
            </div>
            <Button variant="outline" onClick={() => router.push('/dashboard')}>
              Back
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-4xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8 flex flex-col">
        <div className="mb-6">
          <h2 className="text-3xl font-bold text-slate-900">Church Assistant</h2>
          <p className="text-slate-600 mt-1">Ask me anything about your church, events, members, or how to get involved</p>
        </div>

        {/* Chat Messages */}
        <Card className="flex-1 p-6 mb-6 overflow-y-auto max-h-[calc(100vh-300px)]">
          {messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <div className="bg-blue-100 p-4 rounded-full mb-4">
                <svg className="w-12 h-12 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                  />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-slate-900 mb-2">Welcome to Church Assistant</h3>
              <p className="text-slate-600 max-w-md">
                I&apos;m here to help you with information about your church, events, members, giving, and more. Feel free to ask me anything!
              </p>
              <div className="mt-6 space-y-2 text-left">
                <p className="text-sm font-medium text-slate-700">Try asking me about:</p>
                <ul className="text-sm text-slate-600 space-y-1">
                  <li>• Upcoming church events and services</li>
                  <li>• How to get involved in church ministries</li>
                  <li>• Prayer request information</li>
                  <li>• Church giving and financial information</li>
                  <li>• Church member contact information</li>
                  <li>• Spiritual guidance and questions</li>
                </ul>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {messages.map((message, index) => (
                <div key={index} className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div
                    className={`max-w-xs lg:max-w-md xl:max-w-lg px-4 py-3 rounded-lg ${
                      message.role === 'user'
                        ? 'bg-blue-600 text-white rounded-br-none'
                        : 'bg-slate-200 text-slate-900 rounded-bl-none'
                    }`}
                  >
                    <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>
          )}
        </Card>

        {/* Input Area */}
        <form onSubmit={handleSubmit} className="flex gap-3">
          <Input
            type="text"
            placeholder="Ask the church assistant..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="flex-1"
            disabled={messages.some((m) => m.role === 'assistant' && !m.content)}
          />
          <Button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white" disabled={!input.trim()}>
            Send
          </Button>
        </form>
      </main>
    </div>
  )
}
