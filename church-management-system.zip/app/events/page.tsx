'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import Link from 'next/link'

interface Event {
  id: string
  event_type: string
  title: string
  description: string | null
  event_date: string
  event_time: string | null
  location: string | null
  created_at: string
}

export default function EventsPage() {
  const [events, setEvents] = useState<Event[]>([])
  const [loading, setLoading] = useState(true)
  const [user, setUser] = useState<any>(null)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Check user role
        const {
          data: { user: authUser },
        } = await supabase.auth.getUser()

        if (!authUser) {
          router.push('/auth/login')
          return
        }

        const { data: userProfile } = await supabase.from('users').select('*').eq('id', authUser.id).single()

        if (userProfile?.role !== 'admin' && userProfile?.role !== 'secretary') {
          router.push('/dashboard')
          return
        }

        setUser(userProfile)

        // Fetch events
        const { data: eventsData } = await supabase
          .from('events')
          .select('*')
          .order('event_date', { ascending: true })

        if (eventsData) {
          setEvents(eventsData)
        }
      } catch (error) {
        console.error('Error fetching events:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [supabase, router])

  const upcomingEvents = events.filter((e) => new Date(e.event_date) >= new Date())
  const pastEvents = events.filter((e) => new Date(e.event_date) < new Date())

  const eventTypeColors: Record<string, string> = {
    sunday_service: 'bg-blue-100 text-blue-800',
    midweek_study: 'bg-purple-100 text-purple-800',
    night_vigil: 'bg-indigo-100 text-indigo-800',
    baptism: 'bg-cyan-100 text-cyan-800',
    revival: 'bg-red-100 text-red-800',
    convention: 'bg-green-100 text-green-800',
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <Link href="/dashboard">
                <h1 className="text-2xl font-bold text-slate-900 hover:text-slate-700">Church Management</h1>
              </Link>
            </div>
            <Button variant="outline" onClick={() => router.push('/dashboard')}>
              Back
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-3xl font-bold text-slate-900">Events & Services</h2>
              <p className="text-slate-600 mt-1">Manage church events and track attendance</p>
            </div>
            <Link href="/events/add">
              <Button className="bg-purple-600 hover:bg-purple-700 text-white">Create Event</Button>
            </Link>
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <p className="text-slate-600">Loading events...</p>
          </div>
        ) : events.length === 0 ? (
          <Card className="p-12 text-center">
            <p className="text-slate-600 mb-4">No events found</p>
            <Link href="/events/add">
              <Button className="bg-purple-600 hover:bg-purple-700 text-white">Create First Event</Button>
            </Link>
          </Card>
        ) : (
          <>
            {/* Upcoming Events */}
            {upcomingEvents.length > 0 && (
              <div className="mb-12">
                <h3 className="text-2xl font-bold text-slate-900 mb-6">Upcoming Events</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {upcomingEvents.map((event) => (
                    <Link key={event.id} href={`/events/${event.id}`}>
                      <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer">
                        <div className="flex items-start justify-between mb-3">
                          <h4 className="text-lg font-semibold text-slate-900">{event.title}</h4>
                          <span
                            className={`px-2 py-1 rounded text-xs font-medium ${
                              eventTypeColors[event.event_type] || 'bg-slate-100 text-slate-800'
                            }`}
                          >
                            {event.event_type.replace(/_/g, ' ')}
                          </span>
                        </div>
                        {event.description && <p className="text-sm text-slate-600 mb-3">{event.description}</p>}
                        <div className="space-y-2 text-sm text-slate-600">
                          <div className="flex items-center gap-2">
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                            </svg>
                            {new Date(event.event_date).toLocaleDateString()} {event.event_time && `at ${event.event_time}`}
                          </div>
                          {event.location && (
                            <div className="flex items-center gap-2">
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                              </svg>
                              {event.location}
                            </div>
                          )}
                        </div>
                      </Card>
                    </Link>
                  ))}
                </div>
              </div>
            )}

            {/* Past Events */}
            {pastEvents.length > 0 && (
              <div>
                <h3 className="text-2xl font-bold text-slate-900 mb-6">Past Events</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 opacity-75">
                  {pastEvents.map((event) => (
                    <Link key={event.id} href={`/events/${event.id}`}>
                      <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer">
                        <div className="flex items-start justify-between mb-3">
                          <h4 className="text-lg font-semibold text-slate-900">{event.title}</h4>
                          <span
                            className={`px-2 py-1 rounded text-xs font-medium ${
                              eventTypeColors[event.event_type] || 'bg-slate-100 text-slate-800'
                            }`}
                          >
                            {event.event_type.replace(/_/g, ' ')}
                          </span>
                        </div>
                        {event.description && <p className="text-sm text-slate-600 mb-3">{event.description}</p>}
                        <div className="space-y-2 text-sm text-slate-600">
                          <div className="flex items-center gap-2">
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                            </svg>
                            {new Date(event.event_date).toLocaleDateString()} {event.event_time && `at ${event.event_time}`}
                          </div>
                          {event.location && (
                            <div className="flex items-center gap-2">
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                              </svg>
                              {event.location}
                            </div>
                          )}
                        </div>
                      </Card>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </main>
    </div>
  )
}
