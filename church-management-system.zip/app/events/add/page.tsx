'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import Link from 'next/link'

const EVENT_TYPES = [
  { value: 'sunday_service', label: 'Sunday Service' },
  { value: 'midweek_study', label: 'Midweek Study' },
  { value: 'night_vigil', label: 'Night Vigil' },
  { value: 'baptism', label: 'Baptism' },
  { value: 'revival', label: 'Revival' },
  { value: 'convention', label: 'Convention' },
]

export default function AddEventPage() {
  const [formData, setFormData] = useState({
    event_type: 'sunday_service',
    title: '',
    description: '',
    event_date: new Date().toISOString().split('T')[0],
    event_time: '09:00',
    location: '',
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [user, setUser] = useState<any>(null)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const checkAuth = async () => {
      const {
        data: { user: authUser },
      } = await supabase.auth.getUser()

      if (!authUser) {
        router.push('/auth/login')
        return
      }

      const { data: userProfile } = await supabase.from('users').select('*').eq('id', authUser.id).single()

      if (userProfile?.role !== 'admin' && userProfile?.role !== 'secretary') {
        router.push('/dashboard')
        return
      }

      setUser(userProfile)
    }

    checkAuth()
  }, [supabase, router])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      const {
        data: { user: authUser },
      } = await supabase.auth.getUser()

      const { error: insertError } = await supabase.from('events').insert({
        ...formData,
        created_by: authUser?.id,
      })

      if (insertError) {
        setError(insertError.message)
      } else {
        router.push('/events')
      }
    } catch (err) {
      setError('Failed to create event. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link href="/events">
            <h1 className="text-2xl font-bold text-slate-900 hover:text-slate-700">Church Management</h1>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card className="p-8">
          <h2 className="text-3xl font-bold text-slate-900 mb-6">Create New Event</h2>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Event Details */}
            <div>
              <h3 className="text-lg font-semibold text-slate-900 mb-4">Event Details</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-slate-900 mb-1">Event Title</label>
                  <Input
                    type="text"
                    name="title"
                    placeholder="e.g., Sunday Morning Service"
                    value={formData.title}
                    onChange={handleChange}
                    required
                    disabled={loading}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-900 mb-1">Event Type</label>
                  <select
                    name="event_type"
                    value={formData.event_type}
                    onChange={handleChange}
                    disabled={loading}
                    className="w-full px-3 py-2 border border-slate-300 rounded-md text-sm"
                  >
                    {EVENT_TYPES.map((type) => (
                      <option key={type.value} value={type.value}>
                        {type.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-900 mb-1">Event Date</label>
                  <Input
                    type="date"
                    name="event_date"
                    value={formData.event_date}
                    onChange={handleChange}
                    required
                    disabled={loading}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-900 mb-1">Event Time</label>
                  <Input
                    type="time"
                    name="event_time"
                    value={formData.event_time}
                    onChange={handleChange}
                    disabled={loading}
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-slate-900 mb-1">Location</label>
                  <Input
                    type="text"
                    name="location"
                    placeholder="e.g., Main Church Hall"
                    value={formData.location}
                    onChange={handleChange}
                    disabled={loading}
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-slate-900 mb-1">Description</label>
                  <textarea
                    name="description"
                    placeholder="Add details about this event..."
                    value={formData.description}
                    onChange={handleChange}
                    disabled={loading}
                    rows={4}
                    className="w-full px-3 py-2 border border-slate-300 rounded-md text-sm"
                  />
                </div>
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md">
                {error}
              </div>
            )}

            <div className="flex gap-4">
              <Button type="submit" className="bg-purple-600 hover:bg-purple-700 text-white" disabled={loading}>
                {loading ? 'Creating...' : 'Create Event'}
              </Button>
              <Link href="/events">
                <Button variant="outline" disabled={loading}>
                  Cancel
                </Button>
              </Link>
            </div>
          </form>
        </Card>
      </main>
    </div>
  )
}
