'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import Link from 'next/link'

interface Announcement {
  id: string
  title: string
  content: string
  is_published: boolean
  published_at: string | null
  created_at: string
  created_by: string | null
}

export default function AnnouncementsPage() {
  const [announcements, setAnnouncements] = useState<Announcement[]>([])
  const [loading, setLoading] = useState(true)
  const [user, setUser] = useState<any>(null)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const fetchData = async () => {
      try {
        const {
          data: { user: authUser },
        } = await supabase.auth.getUser()

        if (!authUser) {
          router.push('/auth/login')
          return
        }

        const { data: userProfile } = await supabase.from('users').select('*').eq('id', authUser.id).single()

        setUser(userProfile)

        // Fetch announcements (published only for non-admins, all for admins)
        const query = supabase.from('announcements').select('*').order('published_at', { ascending: false })

        if (!userProfile || userProfile.role !== 'admin') {
          query.eq('is_published', true)
        }

        const { data: announcementsData } = await query

        if (announcementsData) {
          setAnnouncements(announcementsData)
        }
      } catch (error) {
        console.error('Error fetching announcements:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [supabase, router])

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <Link href="/dashboard">
                <h1 className="text-2xl font-bold text-slate-900 hover:text-slate-700">Church Management</h1>
              </Link>
            </div>
            <Button variant="outline" onClick={() => router.push('/dashboard')}>
              Back
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold text-slate-900">Announcements</h2>
              <p className="text-slate-600 mt-1">Latest church announcements and news</p>
            </div>
            {user?.role === 'admin' && (
              <Link href="/announcements/add">
                <Button className="bg-amber-600 hover:bg-amber-700 text-white">New Announcement</Button>
              </Link>
            )}
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <p className="text-slate-600">Loading announcements...</p>
          </div>
        ) : announcements.length === 0 ? (
          <Card className="p-12 text-center">
            <p className="text-slate-600">No announcements yet</p>
          </Card>
        ) : (
          <div className="space-y-6">
            {announcements.map((announcement) => (
              <Card key={announcement.id} className="p-6">
                <div className="flex items-start justify-between mb-3">
                  <h3 className="text-xl font-semibold text-slate-900">{announcement.title}</h3>
                  {user?.role === 'admin' && (
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        Edit
                      </Button>
                      <Button variant="outline" size="sm" className="text-red-600">
                        Delete
                      </Button>
                    </div>
                  )}
                </div>
                <p className="text-slate-700 mb-4 whitespace-pre-wrap">{announcement.content}</p>
                <div className="flex items-center justify-between text-sm text-slate-500">
                  <span>{new Date(announcement.published_at || announcement.created_at).toLocaleDateString()}</span>
                  {!announcement.is_published && (
                    <span className="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-xs font-medium">
                      Draft
                    </span>
                  )}
                </div>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
