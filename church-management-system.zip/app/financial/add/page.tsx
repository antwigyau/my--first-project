'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import Link from 'next/link'

const SESSION_TYPES = [
  { value: 'tithe', label: 'Tithe' },
  { value: 'offering', label: 'Offering' },
  { value: 'thick', label: 'Thick' },
  { value: 'welfare', label: 'Welfare' },
  { value: 'building_fund', label: 'Building Fund' },
  { value: 'mission', label: 'Mission' },
  { value: 'special', label: 'Special' },
  { value: 'first_fruit', label: 'First Fruit' },
  { value: 'seed', label: 'Seed' },
]

const PAYMENT_METHODS = [
  { value: 'cash', label: 'Cash' },
  { value: 'momo', label: 'Mobile Money' },
  { value: 'bank_transfer', label: 'Bank Transfer' },
  { value: 'cheque', label: 'Cheque' },
]

export default function AddFinancialSessionPage() {
  const [formData, setFormData] = useState({
    session_type: 'tithe',
    amount: '',
    payment_method: 'cash',
    member_id: '',
    session_date: new Date().toISOString().split('T')[0],
    notes: '',
  })
  const [members, setMembers] = useState<Array<{ id: string; first_name: string; last_name: string }>>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [user, setUser] = useState<any>(null)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const fetchData = async () => {
      try {
        const {
          data: { user: authUser },
        } = await supabase.auth.getUser()

        if (!authUser) {
          router.push('/auth/login')
          return
        }

        const { data: userProfile } = await supabase.from('users').select('*').eq('id', authUser.id).single()

        if (userProfile?.role !== 'admin' && userProfile?.role !== 'treasurer') {
          router.push('/dashboard')
          return
        }

        setUser(userProfile)

        // Fetch members
        const { data: membersData } = await supabase.from('members').select('id, first_name, last_name').eq('is_active', true)

        if (membersData) {
          setMembers(membersData)
        }
      } catch (error) {
        console.error('Error fetching data:', error)
      }
    }

    fetchData()
  }, [supabase, router])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      const {
        data: { user: authUser },
      } = await supabase.auth.getUser()

      const { error: insertError } = await supabase.from('financial_sessions').insert({
        ...formData,
        amount: parseFloat(formData.amount),
        member_id: formData.member_id || null,
        recorded_by: authUser?.id,
      })

      if (insertError) {
        setError(insertError.message)
      } else {
        router.push('/financial')
      }
    } catch (err) {
      setError('Failed to record session. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link href="/financial">
            <h1 className="text-2xl font-bold text-slate-900 hover:text-slate-700">Church Management</h1>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card className="p-8">
          <h2 className="text-3xl font-bold text-slate-900 mb-6">Record Financial Session</h2>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Session Details */}
            <div>
              <h3 className="text-lg font-semibold text-slate-900 mb-4">Session Details</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-900 mb-1">Session Type</label>
                  <select
                    name="session_type"
                    value={formData.session_type}
                    onChange={handleChange}
                    disabled={loading}
                    className="w-full px-3 py-2 border border-slate-300 rounded-md text-sm"
                  >
                    {SESSION_TYPES.map((type) => (
                      <option key={type.value} value={type.value}>
                        {type.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-900 mb-1">Amount (GHS)</label>
                  <Input
                    type="number"
                    name="amount"
                    placeholder="0.00"
                    value={formData.amount}
                    onChange={handleChange}
                    step="0.01"
                    required
                    disabled={loading}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-900 mb-1">Payment Method</label>
                  <select
                    name="payment_method"
                    value={formData.payment_method}
                    onChange={handleChange}
                    disabled={loading}
                    className="w-full px-3 py-2 border border-slate-300 rounded-md text-sm"
                  >
                    {PAYMENT_METHODS.map((method) => (
                      <option key={method.value} value={method.value}>
                        {method.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-900 mb-1">Session Date</label>
                  <Input
                    type="date"
                    name="session_date"
                    value={formData.session_date}
                    onChange={handleChange}
                    required
                    disabled={loading}
                  />
                </div>
              </div>
            </div>

            {/* Member Information */}
            <div>
              <h3 className="text-lg font-semibold text-slate-900 mb-4">Member (Optional)</h3>
              <select
                name="member_id"
                value={formData.member_id}
                onChange={handleChange}
                disabled={loading}
                className="w-full px-3 py-2 border border-slate-300 rounded-md text-sm"
              >
                <option value="">Anonymous/Not Listed</option>
                {members.map((member) => (
                  <option key={member.id} value={member.id}>
                    {member.first_name} {member.last_name}
                  </option>
                ))}
              </select>
            </div>

            {/* Notes */}
            <div>
              <label className="block text-sm font-medium text-slate-900 mb-1">Notes (Optional)</label>
              <textarea
                name="notes"
                placeholder="Add any notes about this session..."
                value={formData.notes}
                onChange={handleChange}
                disabled={loading}
                rows={4}
                className="w-full px-3 py-2 border border-slate-300 rounded-md text-sm"
              />
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md">
                {error}
              </div>
            )}

            <div className="flex gap-4">
              <Button type="submit" className="bg-green-600 hover:bg-green-700 text-white" disabled={loading}>
                {loading ? 'Recording...' : 'Record Session'}
              </Button>
              <Link href="/financial">
                <Button variant="outline" disabled={loading}>
                  Cancel
                </Button>
              </Link>
            </div>
          </form>
        </Card>
      </main>
    </div>
  )
}
