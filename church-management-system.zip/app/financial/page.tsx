'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import Link from 'next/link'

interface FinancialSession {
  id: string
  session_type: string
  amount: number
  payment_method: string
  session_date: string
  member_id: string | null
  recorded_by: string | null
  notes: string | null
  created_at: string
}

interface Member {
  id: string
  first_name: string
  last_name: string
}

export default function FinancialPage() {
  const [sessions, setSessions] = useState<FinancialSession[]>([])
  const [members, setMembers] = useState<Record<string, Member>>({})
  const [loading, setLoading] = useState(true)
  const [filterType, setFilterType] = useState('all')
  const [user, setUser] = useState<any>(null)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Check user role
        const {
          data: { user: authUser },
        } = await supabase.auth.getUser()

        if (!authUser) {
          router.push('/auth/login')
          return
        }

        const { data: userProfile } = await supabase.from('users').select('*').eq('id', authUser.id).single()

        if (userProfile?.role !== 'admin' && userProfile?.role !== 'treasurer') {
          router.push('/dashboard')
          return
        }

        setUser(userProfile)

        // Fetch financial sessions
        const { data: sessionsData } = await supabase
          .from('financial_sessions')
          .select('*')
          .order('session_date', { ascending: false })

        if (sessionsData) {
          setSessions(sessionsData)

          // Fetch member names
          const memberIds = [...new Set(sessionsData.map((s) => s.member_id).filter(Boolean))]
          if (memberIds.length > 0) {
            const { data: membersData } = await supabase.from('members').select('id, first_name, last_name').in('id', memberIds)

            const memberMap: Record<string, Member> = {}
            membersData?.forEach((m) => {
              memberMap[m.id] = m
            })
            setMembers(memberMap)
          }
        }
      } catch (error) {
        console.error('Error fetching financial data:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [supabase, router])

  const filteredSessions = filterType === 'all' ? sessions : sessions.filter((s) => s.session_type === filterType)

  const totalAmount = filteredSessions.reduce((sum, s) => sum + s.amount, 0)

  const sessionTypes = [
    { value: 'tithe', label: 'Tithe' },
    { value: 'offering', label: 'Offering' },
    { value: 'thick', label: 'Thick' },
    { value: 'welfare', label: 'Welfare' },
    { value: 'building_fund', label: 'Building Fund' },
    { value: 'mission', label: 'Mission' },
    { value: 'special', label: 'Special' },
    { value: 'first_fruit', label: 'First Fruit' },
    { value: 'seed', label: 'Seed' },
  ]

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <Link href="/dashboard">
                <h1 className="text-2xl font-bold text-slate-900 hover:text-slate-700">Church Management</h1>
              </Link>
            </div>
            <Button variant="outline" onClick={() => router.push('/dashboard')}>
              Back
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-3xl font-bold text-slate-900">Financial Sessions</h2>
              <p className="text-slate-600 mt-1">Track tithes, offerings, and giving</p>
            </div>
            <Link href="/financial/add">
              <Button className="bg-green-600 hover:bg-green-700 text-white">Record Session</Button>
            </Link>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <Card className="p-6">
              <p className="text-sm text-slate-600 mb-2">Total Amount ({filterType === 'all' ? 'All Types' : sessionTypes.find((t) => t.value === filterType)?.label})</p>
              <p className="text-3xl font-bold text-slate-900">GHS {totalAmount.toFixed(2)}</p>
            </Card>
            <Card className="p-6">
              <p className="text-sm text-slate-600 mb-2">Total Sessions</p>
              <p className="text-3xl font-bold text-slate-900">{filteredSessions.length}</p>
            </Card>
          </div>

          {/* Filter */}
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-4 py-2 border border-slate-300 rounded-md mb-6"
          >
            <option value="all">All Types</option>
            {sessionTypes.map((type) => (
              <option key={type.value} value={type.value}>
                {type.label}
              </option>
            ))}
          </select>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <p className="text-slate-600">Loading financial sessions...</p>
          </div>
        ) : filteredSessions.length === 0 ? (
          <Card className="p-12 text-center">
            <p className="text-slate-600 mb-4">No sessions found</p>
            <Link href="/financial/add">
              <Button className="bg-green-600 hover:bg-green-700 text-white">Record First Session</Button>
            </Link>
          </Card>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-100 border-b border-slate-200">
                <tr>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-slate-900">Date</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-slate-900">Type</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-slate-900">Amount</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-slate-900">Payment Method</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-slate-900">Member</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-slate-900">Notes</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-slate-900">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {filteredSessions.map((session) => (
                  <tr key={session.id} className="hover:bg-slate-50">
                    <td className="px-6 py-4 text-sm text-slate-900">
                      {new Date(session.session_date).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-600 capitalize">
                      {session.session_type.replace(/_/g, ' ')}
                    </td>
                    <td className="px-6 py-4 text-sm font-semibold text-green-600">GHS {session.amount.toFixed(2)}</td>
                    <td className="px-6 py-4 text-sm text-slate-600 capitalize">{session.payment_method}</td>
                    <td className="px-6 py-4 text-sm text-slate-600">
                      {session.member_id && members[session.member_id]
                        ? `${members[session.member_id].first_name} ${members[session.member_id].last_name}`
                        : 'Anonymous'}
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-600">{session.notes || '-'}</td>
                    <td className="px-6 py-4 text-sm">
                      <Button variant="outline" size="sm">
                        View
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </main>
    </div>
  )
}
