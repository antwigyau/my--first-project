import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'

export default function WelcomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50">
      {/* Header */}
      <div className="max-w-6xl mx-auto px-4 py-16 text-center">
        <h1 className="text-5xl font-bold text-slate-900 mb-4">
          Church Management System
        </h1>
        <p className="text-xl text-slate-600 max-w-2xl mx-auto">
          Complete solution for managing members, finances, events, and more
        </p>
      </div>

      {/* Quick Start Section */}
      <div className="max-w-6xl mx-auto px-4 py-12">
        <h2 className="text-3xl font-bold text-slate-900 mb-8 text-center">Get Started in 3 Easy Steps</h2>
        
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {/* Sign Up Option */}
          <Card className="p-8 border-2 border-blue-200 bg-white">
            <div className="text-center mb-6">
              <div className="inline-block bg-blue-100 text-blue-600 rounded-full w-12 h-12 flex items-center justify-center font-bold text-lg mb-4">
                1
              </div>
              <h3 className="text-2xl font-bold text-slate-900">Sign Up</h3>
            </div>
            <p className="text-slate-600 mb-6 text-center">
              Create a new account with any email and password. Takes 30 seconds.
            </p>
            <Link href="/auth/sign-up" className="block">
              <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white text-lg py-6">
                Go to Sign Up
              </Button>
            </Link>
            <p className="text-sm text-slate-500 mt-4 text-center">
              Or if you already have an account, <Link href="/auth/login" className="text-blue-600 hover:text-blue-700 font-medium">sign in here</Link>
            </p>
          </Card>

          {/* Auto Login */}
          <Card className="p-8 border-2 border-green-200 bg-white">
            <div className="text-center mb-6">
              <div className="inline-block bg-green-100 text-green-600 rounded-full w-12 h-12 flex items-center justify-center font-bold text-lg mb-4">
                2
              </div>
              <h3 className="text-2xl font-bold text-slate-900">Auto Login</h3>
            </div>
            <p className="text-slate-600 mb-6 text-center">
              After signing up, you&apos;ll be automatically logged in. No email confirmation needed.
            </p>
            <div className="bg-green-50 border border-green-200 rounded-md p-4">
              <p className="text-sm text-green-900 font-mono">
                ✓ Account created<br/>
                ✓ Session started<br/>
                ✓ Redirected to dashboard
              </p>
            </div>
          </Card>
        </div>

        {/* Access Dashboard */}
        <div className="text-center mb-12">
          <Card className="p-8 border-2 border-purple-200 bg-white max-w-md mx-auto">
            <div className="text-center mb-6">
              <div className="inline-block bg-purple-100 text-purple-600 rounded-full w-12 h-12 flex items-center justify-center font-bold text-lg mb-4">
                3
              </div>
              <h3 className="text-2xl font-bold text-slate-900">Access Dashboard</h3>
            </div>
            <p className="text-slate-600 mb-6 text-center">
              You&apos;ll see all features available to your role. Start managing your church!
            </p>
            <Link href="/dashboard" className="block">
              <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white text-lg py-6">
                Go to Dashboard
              </Button>
            </Link>
          </Card>
        </div>
      </div>

      {/* Features Section */}
      <div className="bg-slate-900 text-white py-16">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-center">Powerful Features</h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: 'Member Management',
                description: 'Track members, contact info, zones, and departments'
              },
              {
                title: 'Financial Tracking',
                description: 'Record tithes, offerings, and other giving types'
              },
              {
                title: 'Event Management',
                description: 'Create events and track attendance'
              },
              {
                title: 'Announcements',
                description: 'Broadcast important church announcements'
              },
              {
                title: 'Prayer Requests',
                description: 'Community prayer request system'
              },
              {
                title: 'AI Assistant',
                description: 'Ask Claude AI about your church data'
              }
            ].map((feature, i) => (
              <Card key={i} className="p-6 bg-slate-800 border-slate-700">
                <h3 className="text-lg font-bold mb-2">{feature.title}</h3>
                <p className="text-slate-300">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </div>

      {/* Role-Based Access */}
      <div className="max-w-6xl mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-slate-900 mb-12 text-center">
          Different Access Levels for Different Roles
        </h2>

        <div className="grid md:grid-cols-3 gap-6">
          {[
            {
              role: 'Admin',
              color: 'red',
              features: ['All members', 'All financials', 'Create events', 'Create announcements', 'System settings']
            },
            {
              role: 'Treasurer',
              color: 'green',
              features: ['Record giving', 'View members', 'Financial reports']
            },
            {
              role: 'Member',
              color: 'blue',
              features: ['Submit prayer requests', 'View announcements', 'View events']
            }
          ].map((role, i) => {
            const colorClass = role.color === 'red' ? 'border-red-200 bg-red-50' : 
                              role.color === 'green' ? 'border-green-200 bg-green-50' : 
                              'border-blue-200 bg-blue-50'
            const textClass = role.color === 'red' ? 'text-red-900' : 
                             role.color === 'green' ? 'text-green-900' : 
                             'text-blue-900'
            
            return (
              <Card key={i} className={`p-6 border-2 ${colorClass}`}>
                <h3 className={`text-xl font-bold ${textClass} mb-4`}>{role.role}</h3>
                <ul className={`space-y-2 ${textClass}`}>
                  {role.features.map((feature, j) => (
                    <li key={j} className="flex items-start">
                      <span className="mr-2">✓</span>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </Card>
            )
          })}
        </div>
      </div>

      {/* Call to Action */}
      <div className="bg-blue-600 text-white py-16">
        <div className="max-w-2xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Get Started?</h2>
          <p className="text-lg mb-8 opacity-90">
            It takes less than a minute to set up your church account
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/auth/sign-up">
              <Button className="bg-white text-blue-600 hover:bg-blue-50 font-bold text-lg px-8 py-3">
                Create Account
              </Button>
            </Link>
            <Link href="/auth/login">
              <Button variant="outline" className="border-white text-white hover:bg-blue-700 font-bold text-lg px-8 py-3">
                Sign In
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="bg-slate-900 text-slate-400 py-8 text-center">
        <p>
          Questions? Check the Quick Start Guide or visit the dashboard
        </p>
      </div>
    </div>
  )
}
