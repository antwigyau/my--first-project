import { createClient } from '@/lib/supabase/server'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import Link from 'next/link'

interface DashboardStats {
  totalMembers: number
  totalFinancial: number
  upcomingEvents: number
  prayerRequests: number
}

async function getStats(supabase: any): Promise<DashboardStats> {
  try {
    const [members, financial, events, prayers] = await Promise.all([
      supabase.from('members').select('id', { count: 'exact' }),
      supabase.from('financial_sessions').select('amount'),
      supabase
        .from('events')
        .select('id', { count: 'exact' })
        .gte('event_date', new Date().toISOString().split('T')[0]),
      supabase.from('prayer_requests').select('id', { count: 'exact' }).eq('is_resolved', false),
    ])

    const totalFinancial =
      financial.data?.reduce((sum: number, item: any) => sum + (parseFloat(item.amount) || 0), 0) || 0

    return {
      totalMembers: members.count || 0,
      totalFinancial,
      upcomingEvents: events.count || 0,
      prayerRequests: prayers.count || 0,
    }
  } catch (error) {
    console.error('[v0] Error fetching stats:', error)
    return {
      totalMembers: 0,
      totalFinancial: 0,
      upcomingEvents: 0,
      prayerRequests: 0,
    }
  }
}

export default async function DashboardPage() {
  // Using default admin user without authentication
  const user = {
    id: 'default-admin',
    email: 'admin@church.local',
    role: 'admin',
    first_name: 'Admin',
    last_name: 'User',
  }

  const supabase = await createClient()
  const stats = await getStats(supabase)

  const isAdmin = user.role === 'admin'
  const isTreasurer = user.role === 'treasurer'
  const isSecretary = user.role === 'secretary'

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Church Management</h1>
            <p className="text-sm text-slate-600">
              Welcome, {user.first_name} ({user.role})
            </p>
          </div>
          <div className="text-sm text-slate-500">Demo Mode - No Authentication</div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Total Members</p>
                <p className="text-3xl font-bold text-slate-900">{stats.totalMembers}</p>
              </div>
              <div className="bg-blue-100 p-3 rounded-lg">
                <svg
                  className="w-6 h-6 text-blue-600"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 4.354a4 4 0 110 5.292M15 21H3v-2a6 6 0 0112 0v2zm0 0h6v-2a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"
                  />
                </svg>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Total Giving</p>
                <p className="text-3xl font-bold text-slate-900">
                  GH₵ {stats.totalFinancial.toFixed(2)}
                </p>
              </div>
              <div className="bg-green-100 p-3 rounded-lg">
                <svg
                  className="w-6 h-6 text-green-600"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Upcoming Events</p>
                <p className="text-3xl font-bold text-slate-900">{stats.upcomingEvents}</p>
              </div>
              <div className="bg-purple-100 p-3 rounded-lg">
                <svg
                  className="w-6 h-6 text-purple-600"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                  />
                </svg>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Prayer Requests</p>
                <p className="text-3xl font-bold text-slate-900">{stats.prayerRequests}</p>
              </div>
              <div className="bg-amber-100 p-3 rounded-lg">
                <svg
                  className="w-6 h-6 text-amber-600"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"
                  />
                </svg>
              </div>
            </div>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <h2 className="text-xl font-bold text-slate-900 mb-4">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {isAdmin && (
              <>
                <Link href="/members/add">
                  <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer">
                    <h3 className="text-lg font-semibold text-slate-900 mb-2">Add Member</h3>
                    <p className="text-sm text-slate-600 mb-4">Register a new church member</p>
                    <span className="text-blue-600 text-sm font-medium">Add Member →</span>
                  </Card>
                </Link>

                <Link href="/financial/add">
                  <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer">
                    <h3 className="text-lg font-semibold text-slate-900 mb-2">Record Giving</h3>
                    <p className="text-sm text-slate-600 mb-4">Record a financial session</p>
                    <span className="text-green-600 text-sm font-medium">Record Giving →</span>
                  </Card>
                </Link>

                <Link href="/events/add">
                  <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer">
                    <h3 className="text-lg font-semibold text-slate-900 mb-2">Create Event</h3>
                    <p className="text-sm text-slate-600 mb-4">Schedule a new church event</p>
                    <span className="text-purple-600 text-sm font-medium">Create Event →</span>
                  </Card>
                </Link>
              </>
            )}

            <Link href="/members">
              <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer">
                <h3 className="text-lg font-semibold text-slate-900 mb-2">Members</h3>
                <p className="text-sm text-slate-600 mb-4">View all church members</p>
                <span className="text-blue-600 text-sm font-medium">View Members →</span>
              </Card>
            </Link>

            <Link href="/financial">
              <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer">
                <h3 className="text-lg font-semibold text-slate-900 mb-2">Finances</h3>
                <p className="text-sm text-slate-600 mb-4">View financial sessions</p>
                <span className="text-green-600 text-sm font-medium">View Finances →</span>
              </Card>
            </Link>

            <Link href="/events">
              <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer">
                <h3 className="text-lg font-semibold text-slate-900 mb-2">Events</h3>
                <p className="text-sm text-slate-600 mb-4">Manage church events</p>
                <span className="text-purple-600 text-sm font-medium">View Events →</span>
              </Card>
            </Link>

            <Link href="/announcements">
              <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer">
                <h3 className="text-lg font-semibold text-slate-900 mb-2">Announcements</h3>
                <p className="text-sm text-slate-600 mb-4">Church announcements</p>
                <span className="text-amber-600 text-sm font-medium">View Announcements →</span>
              </Card>
            </Link>

            <Link href="/prayer-requests">
              <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer">
                <h3 className="text-lg font-semibold text-slate-900 mb-2">Prayer Requests</h3>
                <p className="text-sm text-slate-600 mb-4">Share prayer requests</p>
                <span className="text-pink-600 text-sm font-medium">View Prayer →</span>
              </Card>
            </Link>

            <Link href="/assistant">
              <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer border-2 border-blue-200">
                <h3 className="text-lg font-semibold text-slate-900 mb-2">Church Assistant</h3>
                <p className="text-sm text-slate-600 mb-4">Ask AI questions about church</p>
                <span className="text-blue-600 text-sm font-medium">Open Chat →</span>
              </Card>
            </Link>
          </div>
        </div>

        {/* Admin Section */}
        {isAdmin && (
          <div className="mb-8">
            <h2 className="text-xl font-bold text-slate-900 mb-4">Admin Section</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Link href="/admin">
                <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer bg-red-50 border border-red-200">
                  <h3 className="text-lg font-semibold text-red-900 mb-2">Admin Panel</h3>
                  <p className="text-sm text-red-700 mb-4">System settings and user management</p>
                  <span className="text-red-600 text-sm font-medium">Go to Admin →</span>
                </Card>
              </Link>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}
