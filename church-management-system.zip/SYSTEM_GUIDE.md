# Church Management System - Complete Guide

## System Overview

This is a full-featured Church Management System built with Next.js, Supabase, and Claude AI. It supports role-based access control, member management, financial tracking, events, prayer requests, and more.

---

## Authentication & Access Flow

### How Authentication Works

The system uses Supabase for authentication with the following flow:

1. **Sign Up** → User creates account with email/password
2. **Auto Login** → User is automatically logged in after signup
3. **Session Creation** → JWT token stored in secure cookies
4. **Dashboard Access** → User redirected to dashboard with role-based access

### Email Confirmation (Disabled)

Email confirmation is disabled in development mode, so users can immediately access the system after signup. This makes testing easy.

---

## Getting Started

### Quick Start (Recommended)

**Step 1: Sign Up**
- Go to `/auth/sign-up`
- Fill in: First Name, Last Name, Email, Password
- Click "Sign Up"
- ✓ You'll be automatically logged in!

**Step 2: Access Dashboard**
- You'll be redirected to `/dashboard`
- Your role determines what you see

**Step 3: Start Using Features**
- Explore members, financial, events modules
- Invite other users to sign up

### Alternative: Demo Account

If you want to test with admin credentials first:
1. Go to `/auth/login`
2. See the demo credentials displayed
3. Email: `admin@church.local`
4. Password: `Admin123456!`
5. Note: Demo account needs manual creation (see Setup section)

---

## User Roles & Access Control

### Role Hierarchy

| Role | Access Level | Key Features |
|------|------------|--------------|
| **Admin** | Full | Everything - members, financial, events, settings, admin panel |
| **Treasurer** | High | Financial sessions, member view, reporting |
| **Secretary** | Medium | Members, events, attendance marking |
| **Deacon** | Medium | Member directory, prayer requests |
| **Member** | Basic | Prayer requests, announcements, view-only |

### How Role-Based Access Works

1. **Database Level**: RLS (Row Level Security) policies control database access
2. **UI Level**: Dashboard shows different features based on user role
3. **Route Level**: Protected routes redirect unauthorized users to login

### Setting User Roles

- **On Signup**: All new users default to "Member" role
- **Admin Assignment**: Only admins can change user roles (via admin panel)
- **Editing**: Admins can edit user roles in the admin panel

---

## Database Schema

### Key Tables

#### `auth.users` (Supabase managed)
- Stores authentication credentials
- Email, password hash, confirmed status

#### `public.users`
- User profile information
- Extends auth.users with role, name, phone, zone, department

#### `public.members`
- Church members directory
- Personal info, contact details, emergency contacts, zones, departments

#### `public.financial_sessions`
- Records of giving/tithes
- Amount, type, payment method, date, associated member

#### `public.events`
- Church events and services
- Title, date, time, type, location

#### `public.attendance`
- Event attendance tracking
- Member, event, status (present/late/absent)

#### `public.prayer_requests`
- Community prayer request system
- Title, description, submitter, resolved status

#### `public.announcements`
- Church announcements
- Title, content, publish status

---

## Features in Detail

### Dashboard
- Real-time statistics
- Total members count
- Total giving amount
- Upcoming events
- Recent prayer requests
- Quick access navigation

### Members Management
**View All Members**
- Search by name, email, phone
- Filter by zone or department
- View contact information

**Add New Member**
- Personal details (name, DOB)
- Contact information
- Emergency contact
- Zone and department assignment
- Member status (active/inactive)

**Edit Member**
- Update any member information
- Mark as inactive
- Admins can reassign zones/departments

### Financial Sessions
**Record Giving**
- Amount entered
- Session type selected (tithe, offering, welfare, etc.)
- Payment method selected (cash, mobile, bank, cheque)
- Member associated (optional)
- Date and notes recorded

**View Reports**
- Total giving by type
- Payment method breakdown
- Member contribution summary
- Date-range filtering

### Events Management
**Create Event**
- Event type selected
- Date and time set
- Location specified
- Description added

**Manage Attendance**
- Open event
- Mark members present/late/absent
- View attendance summary
- Export attendance report

### Prayer Requests
**Submit Request**
- Title and description
- Privacy option (public/private)
- Submit and share with community

**View Requests**
- See all community requests
- Filter by status
- Admins can mark as resolved

### AI Assistant
- Ask questions about church data
- Get statistics
- Powered by Claude AI
- Context-aware responses

---

## Admin Panel Features

The Admin Panel provides:
- User management (add, edit, remove)
- Role assignment
- System settings
- Data export options
- Backup management

**Access**: Only admins can access `/admin`

---

## Security Features

### Row Level Security (RLS)
- Database-level access control
- Users can only see authorized data
- Role-based policies enforce permissions

### Password Security
- Passwords hashed with bcrypt (via Supabase)
- Minimum security requirements enforced
- Password reset available

### Session Management
- JWT tokens in HTTP-only cookies
- Automatic token refresh
- Logout clears session

### Data Privacy
- Sensitive data protected via RLS
- Prayer requests privacy options
- Member data restricted by role

---

## Troubleshooting

### "Invalid login credentials"
**Cause**: User hasn't signed up yet or wrong password
**Solution**: Go to `/auth/sign-up` to create account first

### Can't access dashboard
**Cause**: Not logged in or session expired
**Solution**: Log in at `/auth/login`

### Demo admin not working
**Cause**: Demo account not created
**Solution**: Manually create via setup endpoint or sign up regularly

### Role-based features not showing
**Cause**: Your role doesn't have permission
**Solution**: Ask admin to change your role, or sign up as admin test account

### Database connection errors
**Cause**: Supabase env vars not configured
**Solution**: Check NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY

---

## Environment Variables

Required configuration:
```
NEXT_PUBLIC_SUPABASE_URL=your-supabase-url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-supabase-anon-key
```

These are automatically set when you connect Supabase integration.

---

## Common Tasks

### Create an Admin Account
1. Sign up with your email
2. Wait for admin to promote you (or have existing admin do it)
3. Or create demo admin account via setup

### Add Members to Church
1. Go to `/members`
2. Click "Add Member"
3. Fill in details
4. Submit
5. Member appears in directory

### Record Giving/Tithe
1. Go to `/financial`
2. Click "Record Giving"
3. Select amount, type, payment method
4. Associate with member if applicable
5. Submit
6. Appears in financial reports

### Create Event
1. Go to `/events`
2. Click "Create Event"
3. Set title, date, time, location
4. Add description
5. Submit
6. Can now mark attendance

### Submit Prayer Request
1. Go to `/prayer-requests`
2. Click "Submit Request"
3. Write title and description
4. Choose privacy setting
5. Submit
6. Community can see and pray

---

## Tips for Best Experience

1. **Test All Roles**: Create multiple accounts with different roles
2. **Populate Data**: Add sample members, events, giving to test features
3. **Use Admin Panel**: Explore admin settings
4. **Try AI Assistant**: Ask it questions about your data
5. **Check Reports**: View financial and attendance reports

---

## Support & Help

- **Quick Start**: See `/QUICKSTART.md`
- **Setup Instructions**: See `/SETUP.md`
- **Welcome Page**: Visit `/welcome` for overview

---

**You're all set to manage your church efficiently!** 🎉
