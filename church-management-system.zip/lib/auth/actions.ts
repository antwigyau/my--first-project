'use server'

import { createClient } from '@/lib/supabase/server'

export async function createUserProfile(userId: string, email: string, firstName?: string, lastName?: string) {
  const supabase = await createClient()

  try {
    const { error } = await supabase.from('users').insert({
      id: userId,
      email,
      first_name: firstName,
      last_name: lastName,
      role: 'member',
    })

    if (error) {
      console.error('Error creating user profile:', error)
      return { success: false, error: error.message }
    }

    return { success: true }
  } catch (err) {
    console.error('Error in createUserProfile:', err)
    return { success: false, error: 'Failed to create user profile' }
  }
}

export async function getCurrentUser() {
  const supabase = await createClient()

  try {
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return null
    }

    const { data: userProfile, error } = await supabase.from('users').select('*').eq('id', user.id).single()

    if (error) {
      return null
    }

    return userProfile
  } catch (err) {
    console.error('Error getting current user:', err)
    return null
  }
}

export async function signOut() {
  const supabase = await createClient()
  await supabase.auth.signOut()
}
