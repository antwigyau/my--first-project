# Church Management System - Quick Start Guide

## Getting Started (2 Simple Steps)

### Option 1: Sign Up (Recommended - Easiest)

1. **Go to Sign Up Page**: Navigate to `/auth/sign-up`
2. **Fill in the form**:
   - First Name: Any name (e.g., "John")
   - Last Name: Any name (e.g., "Doe")
   - Email: Any email (e.g., "john@example.com")
   - Password: Any secure password
3. **Click Sign Up**
4. **You'll be automatically logged in and redirected to the dashboard!**

That's it! You now have a full account with access to the church management system.

---

### Option 2: Use Demo Admin Account

If you want to test with pre-created credentials:

1. **Go to Login Page**: `/auth/login`
2. **Click "Try Demo Admin Account"** button - it auto-fills the credentials
3. **Click Sign In**
4. **You'll see the full admin dashboard with all features**

**Demo Admin Credentials**:
- Email: `admin@church.local`
- Password: `Admin123456!`

> **Note**: The demo admin account needs to be created first. It will be created automatically when you first click the demo button on the login page.

---

## Dashboard Access by Role

Once logged in, you'll see different features based on your account role:

### Admin Role (Full Access)
- View all members
- Manage financial sessions (tithes, offerings, etc.)
- Create and manage events
- Create announcements
- View all prayer requests
- Access admin settings

### Member Role (Basic Access)
- Submit and view prayer requests
- View announcements
- See upcoming events

### Other Roles
- **Treasurer**: Can manage financial sessions
- **Secretary**: Can manage members and events
- **Deacon**: Can view members and prayer requests

---

## System Features

### Dashboard
Central hub showing:
- Total members count
- Total financial contributions
- Upcoming events
- Recent prayer requests
- Quick access to all modules

### Members Management
- View complete member directory
- Add new members with:
  - Personal information
  - Contact details
  - Emergency contact info
  - Zone and department assignment
- Search and filter members

### Financial Sessions
- Record giving (tithes, offerings, etc.)
- Track by type:
  - Tithe
  - Offering
  - Welfare
  - Building fund
  - Mission
  - And more
- Record payment method (cash, mobile money, bank transfer, cheque)
- Add notes for each session

### Events & Attendance
- Create church events (services, revivals, etc.)
- Record attendance
- Mark members as present, late, or absent
- Track attendance history

### Announcements
- View important church announcements
- Admins can create and publish announcements

### Prayer Requests
- Submit prayer requests
- View community prayer requests
- Track request status (resolved/pending)

### AI Assistant
- Ask questions about the church
- Get statistics and information
- Powered by Claude AI

---

## Troubleshooting

### "Invalid login credentials"
**Solution**: Make sure you've signed up first or use the sign-up page to create an account.

### Can't access dashboard
**Solution**: You'll be automatically redirected to login if:
- You're not logged in
- Your session expired
Just log in again!

### Demo admin not working
**Solution**: Demo admin account is created automatically. Just:
1. Go to `/auth/login`
2. Click "Try Demo Admin Account"
3. The account will be created if it doesn't exist

---

## Navigating the App

### Main Navigation (in Dashboard)
- **Dashboard**: Home view with stats
- **Members**: Manage church members
- **Financial**: Record and track giving
- **Events**: Create and manage events
- **Announcements**: View church announcements
- **Prayer**: Prayer request community
- **Assistant**: AI-powered chatbot
- **Admin** (Admin only): System settings

### Sign Out
Click your email at the top right of the dashboard to sign out.

---

## Tips for Best Experience

1. **Create Multiple Test Accounts**: Sign up with different emails to test different roles
2. **Use All Features**: Try adding members, recording giving, creating events
3. **Check Admin Panel**: If admin, explore the admin settings
4. **Ask the Assistant**: Use the AI assistant to query church data

---

## Support

If you encounter any issues:
1. Check the troubleshooting section above
2. Clear your browser cache and refresh
3. Try signing out and back in
4. Check that Supabase environment variables are configured

---

**You're all set! Start by signing up or logging in now.** 🎉
