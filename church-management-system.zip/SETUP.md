# Church Management System - Setup Guide

## Quick Start

### Step 1: Visit the Setup Page
Navigate to `/setup` in your browser to initialize the demo admin account.

### Step 2: Create Demo Admin Account
Click the **"Create Demo Admin Account"** button. This will:
- Create an admin user in Supabase Authentication
- Set up the user profile in the database
- Email confirmation will be automatic

### Step 3: Login to Dashboard
Go to `/auth/login` and use these credentials:
- **Email:** `admin@church.local`
- **Password:** `Admin123456!`

You'll be redirected to the dashboard where you can explore all features.

---

## Default Demo Credentials

```
Email: admin@church.local
Password: Admin123456!
Role: Admin (full access)
```

---

## User Roles & Permissions

### Admin
- Full access to all features
- Manage members
- View/modify financial records
- Create and manage events
- View announcements
- Access admin panel
- Manage user roles

### Treasurer
- View financial records
- Record giving sessions (tithes, offerings, etc.)
- Generate financial reports
- View member list

### Secretary
- Manage member directory
- Create and manage events
- Track attendance
- Post announcements
- View member profiles

### Deacon
- View member directory
- Attend events
- Submit prayer requests
- View announcements

### Member
- View announcements
- Submit prayer requests
- Participate in events
- Limited member directory access

---

## System Pages

### Public Pages
- `/` - Welcome & Home redirect
- `/welcome` - Feature overview and getting started
- `/auth/login` - Login page
- `/auth/sign-up` - Sign-up page
- `/auth/sign-up-success` - Sign-up confirmation
- `/auth/error` - Authentication errors

### Protected Pages (Require Login)
- `/dashboard` - Main dashboard with role-based overview
- `/members` - Member management
- `/members/add` - Add new member
- `/financial` - Financial tracking
- `/financial/add` - Record new giving session
- `/events` - Event management
- `/events/add` - Create new event
- `/announcements` - Church announcements
- `/prayer-requests` - Prayer request management
- `/prayer-requests/add` - Submit prayer request
- `/assistant` - AI chat assistant
- `/admin` - Admin control panel (Admin only)
- `/setup` - Database setup page

---

## Database Schema

The system uses PostgreSQL with the following main tables:

### users
- User profiles with roles and permissions
- Extended auth.users with additional metadata

### members
- Church member directory
- Contact information
- Department assignments
- Zone assignments
- Emergency contacts

### financial_sessions
- Giving records (tithes, offerings, etc.)
- Payment methods tracked
- Amounts and dates
- Associated members

### events
- Church events and services
- Event types (Sunday service, revival, baptism, etc.)
- Date, time, and location
- Attendance tracking

### attendance
- Event attendance records
- Status tracking (present, late, absent)
- Marked by staff member

### prayer_requests
- Prayer request submissions
- Resolution tracking
- Public or private

### announcements
- Church announcements
- Publication status
- Author tracking

---

## Features Overview

### Member Management
- Add and edit church members
- Track member information (contact, family, department)
- Organize by zones and departments
- View member history

### Financial Tracking
- Record giving sessions with multiple categories:
  - Tithes
  - Offerings
  - Building Fund
  - Mission Fund
  - Special collections
- Multiple payment methods (cash, momo, bank transfer, cheque)
- Generate financial reports
- Track giving trends

### Event Management
- Create church events (Sunday services, revivals, baptisms, etc.)
- Track attendance
- Event details and location management
- Attendance marking interface

### Prayer Management
- Submit community prayer requests
- View public prayer requests
- Track resolution status
- Personal prayer tracking

### Announcements
- Post church-wide announcements
- Publish/unpublish scheduling
- Member viewing

### AI Assistant
- Chat with Claude AI
- Ask questions about church data
- Get quick answers and statistics
- Context-aware responses

---

## Troubleshooting

### Login Issues
If you can't log in:
1. Make sure you've run the setup page (`/setup`)
2. Verify email is exactly: `admin@church.local`
3. Check password matches: `Admin123456!`
4. Ensure email is confirmed (should be auto-confirmed)

### Dashboard Not Loading
If the dashboard doesn't load:
1. Clear browser cache
2. Try logging out and back in
3. Check browser console for errors
4. Ensure Supabase integration is properly configured

### Missing Features
Some features are role-restricted:
- Financial: Admin & Treasurer only
- Events: Admin & Secretary only
- Admin Panel: Admin only

---

## Environment Setup

The app requires these Supabase environment variables (automatically set):
```
NEXT_PUBLIC_SUPABASE_URL=your_project_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
```

These are automatically configured through the Supabase integration.

---

## API Routes

- `POST /api/seed` - Initialize demo admin user
- `POST /api/assistant` - AI assistant chat endpoint

---

## Support

For issues or questions:
1. Check the troubleshooting section above
2. Review database schema and RLS policies
3. Check browser console for error messages
4. Verify all Supabase environment variables are set

---

**Happy managing!** 🙏
